import { Router } from "express";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const router = Router();

router.get("/videos", async (req, res) => {
  const page = parseInt((req.query.page as string) || "1");
  const per = parseInt((req.query.per as string) || "12");

  const videos = await prisma.video.findMany({
    orderBy: { createdAt: "desc" },
    skip: (page - 1) * per,
    take: per,
  });

  res.json({ items: videos, hasMore: videos.length === per });
});

router.post("/videos/create", async (req, res) => {
  const { title, description, url } = req.body;
  const video = await prisma.video.create({
    data: { title, description, url, ownerId: "demo-user" },
  });

  const io = req.app.get("io");
  io.emit("video_ready", video);

  res.json(video);
});

export default router;
