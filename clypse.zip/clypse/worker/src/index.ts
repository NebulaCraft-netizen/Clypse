console.log("Worker started. Simulating video processing...");

setInterval(() => {
  console.log("Worker alive...");
}, 10000);
