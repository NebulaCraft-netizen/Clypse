"use client";

import { useState } from "react";

export default function UploadPage() {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");

  async function handleUpload() {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/videos/create`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, description: desc, url: "/demo.mp4" }),
    });
    if (res.ok) alert("Uploaded!");
  }

  return (
    <main className="p-6">
      <h1 className="text-xl font-bold mb-4">Upload Video</h1>
      <input
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="p-2 mb-2 w-full bg-gray-800 rounded"
      />
      <textarea
        placeholder="Description"
        value={desc}
        onChange={(e) => setDesc(e.target.value)}
        className="p-2 mb-2 w-full bg-gray-800 rounded"
      />
      <button
        onClick={handleUpload}
        className="bg-blue-600 px-4 py-2 rounded hover:bg-blue-500"
      >
        Upload
      </button>
    </main>
  );
}
