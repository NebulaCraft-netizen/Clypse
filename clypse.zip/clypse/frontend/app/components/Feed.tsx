"use client";

import { useEffect, useRef, useState } from "react";
import io from "socket.io-client";

export default function Feed() {
  const [videos, setVideos] = useState<any[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const loaderRef = useRef<HTMLDivElement | null>(null);

  async function fetchPage(p: number) {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/videos?page=${p}&per=6`);
    const data = await res.json();
    setVideos((prev) => [...prev, ...data.items]);
    setHasMore(data.hasMore);
  }

  useEffect(() => { fetchPage(page); }, [page]);

  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && hasMore) setPage((p) => p + 1);
    });
    if (loaderRef.current) obs.observe(loaderRef.current);
    return () => obs.disconnect();
  }, [hasMore]);

  useEffect(() => {
    const socket = io(process.env.NEXT_PUBLIC_API_URL || "");
    socket.on("video_ready", (video) => {
      setVideos((prev) => [video, ...prev]);
    });
    return () => socket.disconnect();
  }, []);

  return (
    <div className="grid gap-4">
      {videos.map((v) => (
        <div key={v.id} className="p-4 bg-gray-800 rounded-lg">
          <h2 className="font-semibold">{v.title}</h2>
          <p className="text-sm text-gray-400">{v.description}</p>
        </div>
      ))}
      <div ref={loaderRef} />
    </div>
  );
}
